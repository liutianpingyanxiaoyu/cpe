/*
	wsc upnp control point related structures

*/
#ifndef __WSC_UPNP_CP_H__
#define __WSC_UPNP_CP_H__


#endif
