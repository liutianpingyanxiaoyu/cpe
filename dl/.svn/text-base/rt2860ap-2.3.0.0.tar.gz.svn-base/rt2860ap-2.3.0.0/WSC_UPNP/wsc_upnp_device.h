

#ifndef __WSC_UPNP_DEVICE_H__
#define __WSC_UPNP_DEVICE_H__




#ifdef __cplusplus
}
#endif

#endif
